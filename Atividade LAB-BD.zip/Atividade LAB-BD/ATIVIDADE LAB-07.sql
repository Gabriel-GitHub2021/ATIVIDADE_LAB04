/*EXERCICIO 3-A*/
select count(*) as Qtde,
		format(max(orçamento), 2,'de_DE') as OrçamentoMaior,
        format(min(orçamento), 2,'de_DE') as OrçamentoMenor,
        format(avg(orçamento), 2,'de_DE') as MédiaProj,
        format(sum(orçamento), 2,'de_DE') as TotalProj
from projeto;

/*EXERCICIO 3-B*/
select codProjeto,
		count(*) as QtdeFat,
		format(max(totalHoras),2) as HoraMaior,
        format(min(totalHoras),2) as HoraMenor,
		format(avg(totalHoras),2) as MédiaHora,
        format(sum(totalHoras),2,'de_DE') as TotalHoras
from faturamento
group by codProjeto;
/* having QtdeFat > 10 */

/*EXERCICIO 3-C*/
select fu.nome as Nome,
	fa.codProjeto as CodigoProj,fa.codFunc as CodigoFunc,
	fa.totalHoras as TotalHoras,
    fu.codCargo as CodCargo,
    ca.nome as NomeCargo
from faturamento as fa, funcionario as fu, cargo as ca
where fa.codFunc = fu.codFunc and ca.codcargo = fu.codcargo
order by totalHoras desc
limit 3;

/*EXERCICIO 4-?*/
select d.coddepto,
		d.nome,
        d.gerente,
        f.nome
from depto as d, funcionario as f
where d.gerente is not null and
	d.gerente = f.codfunc;

/*EXERCICIO 4-C*/
select p.codprojeto as CodProjeto,
	p.cliente as Cliente,
    p.nome as Nome,
    format(p.orçamento, 2, 'de_DE') as Orçamento,
    -- f.codprojeto as CodProjeto,
    f.codfunc as CodFunc
from projeto as p left join faturamento as f
	on (p.codProjeto = f.codprojeto)
where f.codprojeto is null;

select uf.siglauf,
	uf.nome
from funcionario as f right join uf as uf
	on (uf.siglaUF = f.naturalidade) and
    f.codfunc is null